package com.example.week5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "Name ";
    public static final String EXTRA_MESSAGE2 = "id";



    // spinner  // textView

    Spinner sp;
    TextView tv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp = findViewById(R.id.choose_candidate);


    }


    public void choose(View view){

        tv.setText(sp.getSelectedItem().toString());


    }

    public void vote(View view){
        // we are going to go to the next activity!

        Intent intent = new Intent(this, Activity2.class);


        EditText editText = (EditText) findViewById(R.id.nametxt);
        EditText editText1 = (EditText) findViewById(R.id.idtxt);

        String message = editText.getText().toString();
        String message2 = editText1.getText().toString();
        CharSequence spSelectedItem = (CharSequence) sp.getSelectedItem();

        intent.putExtra(EXTRA_MESSAGE, message);
        intent.putExtra(EXTRA_MESSAGE2,message2);

        intent.putExtra("data_spinner_1", spSelectedItem.toString());

        startActivity(intent);
    }

    // this is final call you receive before you destroy your activity
    protected void onDestroy(){

        super.onDestroy();
        Log.d("Main activity", "onDestroy: 1");

    }

    protected void onPause(){
        super.onPause();
        Log.d("Main activity", "onPause: 1");

    }

    protected void onStart(){
        super.onStart();
        Log.d("Main activity", "onStart: 1");

    }

    protected void onStop(){

        super.onStop();
        Log.d("Main Activity", "onStop: 1");
    }

    protected void onRestart(){
        super.onRestart();

        Log.d("Main Activity", "onRestart: 1");
    }

    protected void onResume(){
        super.onResume();

        Log.d("Main Activity", "onResume:1 ");
    }



}
